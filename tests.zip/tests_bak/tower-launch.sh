#!/bin/bash

job_template_id=$(tower-cli job_template list | grep $1 | awk '{print $1}')
job_id=$(tower-cli job launch --job-template=${job_template_id} | grep ${job_template_id} | awk '{print $1}')
tower-cli job monitor ${job_id}
