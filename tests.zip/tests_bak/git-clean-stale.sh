#!/bin/bash

git fetch --all --prune
STALE=$(git branch -vvv | grep ": gone]" | tr -d '*' | awk '{print $1}')
echo $STALE
for branch in ${STALE}; do
  echo -n "Delete ${branch} y/n?"
  read to_delete
  if [ "${to_delete}" == "y" ]; then
    git branch -D ${branch}
  fi
done
