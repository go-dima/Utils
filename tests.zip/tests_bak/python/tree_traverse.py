from typing import List


class dataClass():
  def __init__(self, name):
    self.name = name
    self.children = []
    self.checked = False


  def __repr__(self):
    return str(self.__dict__)


  def add_child(self, *children):
    for child in children:
      self.children.append(child)

  def handle(self):
    self.checked = True


d1 = dataClass("root1")
d2 = dataClass("root2")
d3 = dataClass("root3")

c1 = dataClass("child1")
c2 = dataClass("child2")
c3 = dataClass("child3")

d1.add_child(c1, c2)
d3.add_child(c3)

data = [d1, d2, d3]


for d in data:
  d.handle()
  print(d)
  for child in d.children:
    data.append(child)
