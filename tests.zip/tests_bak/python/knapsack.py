#!/bin/python3

from collections import namedtuple
from typing import List
from operator import add
from functools import reduce

NowLaterPoints = namedtuple('NowLaterPoints', ['step', 'value', 'cost'])

data = [
    NowLaterPoints(3.1, 10, 950),
    NowLaterPoints(5.1, 15, 950),
    NowLaterPoints(7.1, 20, 1800),
    NowLaterPoints(9.1, 25, 2100),
    NowLaterPoints(11.1, 30, 2500),
    NowLaterPoints(13.1, 40, 2900),
    NowLaterPoints(15.1, 50, 4600),
    NowLaterPoints(17.1, 75, 4750),
    NowLaterPoints(19.1, 100, 8000),
    NowLaterPoints(21.1, 200, 9750),
    # NowLaterPoints(23.1, 300, 6000)
]

solutions = set()

def solve_sack(target_sum: int, packed: List[NowLaterPoints], remaining: List[NowLaterPoints]):
    if len(remaining) == 0 or target_sum < 1:
        packed.sort(key=lambda item: item.step)
        sack_value = reduce(add, map(lambda x: x.value, packed))
        sack_cost = reduce(add, map(lambda x: x.cost, packed))
        solutions.add((sack_value, sack_cost, tuple(packed)))
        return

    for idx in range(0, len(remaining)):
        item = remaining[idx]
        if item.cost <= target_sum:
            solve_sack(target_sum-item.cost, packed + [item], remaining[:idx] + remaining[idx+1 :])
        else:
            solve_sack(target_sum, packed, remaining[:idx] + remaining[idx+1 :])

if __name__ == "__main__":
    target_cost = 575 + 900
    solve_sack(target_cost, [], data[:])
    print(len(solutions))

    filtered = list(filter(lambda sol: sol[0], solutions))
    print(len(filtered))

    for solution in sorted(filtered, key=lambda sol: sol[0], reverse=True)[:10]:
        print("-"*50)
        print(f"Value: {solution[0]}, Cost: {solution[1]}, Remaining: {target_cost-solution[1]}")
        for item in solution[2]:
            print(f"\t{item}")
