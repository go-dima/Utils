import backoff
from time import time, sleep
from typing import List


class Response:
    def __init__(self, sc: int):
        self.status_code = sc

def shaky_server(times: int):
    for _ in range(0, times):
        yield Response(500)
    yield Response(200)


def retry(retry_predicate, retries: int=10, retry_interval=5):
    """
    Custom retry decorator

    Args:
        retry_predicate: A predicate used to determine whether retry is needed.
        retries (int, optional): Number of retries. Defaults to 5.
        retry_interval (int, optional): Time to wait between intervals. Defaults to 10.
    """
    def parameters_wrapper(target):
        def decorator(*args, **kwargs):
            retry_count = 0
            while True:
                retry_count += 1
                return_value = target(*args, **kwargs)
                if not retry_predicate(return_value) or retry_count >= retries:
                    return return_value
                sleep(retry_interval)
        return decorator
    return parameters_wrapper


class Sample:
    def __init__(self, times: int):
        self.server = shaky_server(times)

    @backoff.on_predicate(backoff.expo, lambda response: response.status_code == 500, max_tries=5)
    def with_backoff(self):
        return next(self.server)

    @retry(retries=5, retry_interval=10,
           retry_predicate=lambda response: response.status_code == 500)
    def with_retry(self):
        return next(self.server)

print("Backoff")
backoff_3 = Sample(3).with_backoff().status_code
print(backoff_3)
assert backoff_3 == 200

print(10*'-')

backoff_7 = Sample(7).with_backoff().status_code
print(backoff_7)
assert backoff_7 == 500

print("Retry")

retry_3 = Sample(3).with_retry().status_code
print(retry_3)
assert retry_3 == 200

print(10*'-')

retry_7 = Sample(7).with_retry().status_code
print(retry_7)
assert retry_7 == 500
