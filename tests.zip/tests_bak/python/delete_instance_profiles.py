#!/usr/local/bin/python3

import boto3
import argparse
# import time


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--delete', action='store_true', dest='delete',
                        default=False, help='Perform deletion')
    parser.add_argument('-p', '--profile', action='store', dest='aws_profile',
                        default='diamond', help='AWS account profile')
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    boto3.setup_default_session(profile_name=args.aws_profile)
    client = boto3.client('iam')
    response = client.list_instance_profiles(MaxItems=1000)
    profiles_found = response['InstanceProfiles']
    print(f"Found total of {len(profiles_found)} profiles")
    profiles_to_delete = [p for p in profiles_found if len(p['Roles']) == 0]

    for profile in profiles_to_delete:
        print("Deleting", profile['Arn'])
        if args.delete:
            client.delete_instance_profile(
                InstanceProfileName=profile['InstanceProfileName'])

    print(f"Deleted {len(profiles_to_delete)} profiles")
