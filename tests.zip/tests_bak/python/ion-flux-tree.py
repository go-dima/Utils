#!/usr/local/bin/python

from typing import List, Dict


def recursive(h: int, target: int, depth: int, root_value: int, parent: int):
    if depth > h:
        return -1

    right_branch_smallest = (2 ** (h - depth - 1)) - 1
    left_step_diff = 2 ** (h - depth - 1)
    if target >= root_value:
        return parent
    elif target < root_value - right_branch_smallest:
        return recursive(h, target, depth + 1, root_value - left_step_diff, root_value)
    else:
        return recursive(h, target, depth + 1, root_value - 1, root_value)


def iterative(h: int, target: int, depth: int, root_value: int, parent: int):
    parent = -1
    for depth in range(0, h):
        root_value = 2 ** (h - depth) - 1
        right_branch_smallest = (2 ** (h - depth - 1)) - 1
        left_step_diff = 2 ** (h - depth - 1)

        if target >= root_value:
            return parent
        elif target < root_value - right_branch_smallest:
            parent = root_value
            root_value = root_value - left_step_diff
        else:
            parent = root_value
            root_value = root_value - 1
    return -1


def solution(h: int, q: List[int]):
    # sol = []
    # for val in q:
    #     sol.append(sub_sol(h, val, 0, 2 ** h - 1, -1))
    # return sol
    return [recursive(h, target, 0, 2 ** h - 1, -1) for target in q]


def iterative_solution(h: int, q: List[int]):
    return [recursive(h, target, 0, 2 ** h - 1, -1) for target in q]


def test(case: Dict):
    ret_val = solution(case["h"], case["q"])
    print(f"{case['q']} -> {ret_val}")
    return ret_val


def iterative_test(case: Dict):
    ret_val = iterative_solution(case["h"], case["q"])
    print(f"{case['q']} -> {ret_val}")
    return ret_val


test_cases = {
    "case1": {
        "h": 3,
        "q": [7, 3, 5, 1],
        "s": [-1, 7, 6, 3]
    },
    "single": {
        "h": 3,
        "q": [5],
        "s": [6]
    },
    "case2": {
        "h": 5,
        "q": [19, 14, 28],
        "s": [21, 15, 29]
    },
    "case3": {
        "h": 5,
        "q": [10, 21, 22, 24, 33, 27, 1, 5, 12],
        "s": [14, 22, 30, 25, -1, 28, 3, 6, 13]
    }
}

result = test(test_cases["case2"])

for case in test_cases.keys():
    assert test(test_cases[case]) == test_cases[case]["s"]
    assert iterative_test(test_cases[case]) == test_cases[case]["s"]
