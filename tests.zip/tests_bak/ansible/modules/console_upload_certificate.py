#!/usr/bin/python3

DOCUMENTATION = r'''
---
module: console_upload_certificate

short_description: This module send upload cerificate request to console

# If this is part of a collection, you need to use semantic versioning,
# i.e. the version is of the form "2.5.0" and not "2.4".
version_added: "1.0.0"

description: The module accepts console parameters and path to cert files, and invokes a request to upload them

options:
    url:
        description: Console url to interact with
        required: true
        type: str
    token:
        description: Authentication token for specified console
        required: true
        type: str
    customer_id:
        description: ID of the customer to whom we upload the certificates
        required: true
        type: str
    files:
        description: Paths to certificates to upload
        required: true
        type: list[str]

author:
    - Dima Gonikman (dima.gonikman@cyberark.com)
'''

EXAMPLES = r'''

- name: Upload certifiactes
  console_upload_certificate:
    url: https://console.pclouddev.cyberarkcloud.com
    token: <TOKEN HERE>
    customer_id: b95218ad-511d-49a0-95f2-86301aeda72e
    files:
      - /path/to/certs/domain-EC2AMAZ-MO9895T-CA.cer
      - /path/to/certs/EC2AMAZ-MO9895T.domain.com.cer
'''

RETURN = r'''
  http_status:
    description: The http status of the request
    returned: Always
    type: str
    sample: 403
  content:
    description: Content of console response
    returned: Optional (on success)
    type: str
  message:
    description: Error message from console
    returned: Optional (on failure)
    type: str
    sample: User is not authorized to access this resource with an explicit deny
  errors:
    description: Error message(s) from console
    returned: Optional (on failure)
    type: list
    sample: file with name domain-EC2AMAZ-MO9895T-CA.cer already exist for this customer
'''

from ansible.module_utils.basic import AnsibleModule
import requests
import json


def run_module():
    # define available arguments/parameters a user can pass to the module
    module_args = dict(
        url=dict(type='str', required=True),
        token=dict(type='str', required=True),
        customer_id=dict(type='str', required=True),
        files=dict(type='list', required=True)
    )

    # the AnsibleModule object will be our abstraction working with Ansible
    # this includes instantiation, a couple of common attr would be the
    # args/params passed to the execution, as well as if the module
    # supports check mode
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    url = f"{module.params['url']}/files/v1/installCertificate/{module.params['customer_id']}"
    headers = { 'Authorization': f"{module.params['token']}" }
    payload = { 'description': 'This is file description' }

    files=[]
    for filepath in module.params['files']:
        filename = filepath.rsplit('/', 1)[-1]
        files.append(
          ('files',(filename, open(filepath,'rb'),'application/octet-stream'))
        )

    response = requests.request("POST", url, headers=headers, data=payload, files=files)
    console_response = json.loads(response.text)
    console_response['http_status'] = response.status_code
    console_response['changed'] = response.status_code == 202

    if not type(console_response) is dict:
        console_response = {'content': json.loads(response.text)}

    if (response.status_code == 409): # Console returned 409, duplicate
        module.fail_json(msg=console_response['errors'][0], **console_response)

    if (response.status_code == 403): # Console returned 403, not authorized
        module.fail_json(msg=console_response['message'], **console_response)

    module.exit_json(**console_response)

def main():
    run_module()


if __name__ == '__main__':
    main()
