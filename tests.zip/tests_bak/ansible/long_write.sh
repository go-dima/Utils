#!/bin/bash

END=30

echo '' > long_john_run.txt

for i in $(seq 1 $END); do
  echo $i >> long_jhon_run.txt
  sleep 1s
done
