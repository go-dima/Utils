#!/bin/bash

echo ${1:-none}


prefix=${1}.
if [[ -z $1 ]]; then
  prefix=""
fi

echo $prefix

